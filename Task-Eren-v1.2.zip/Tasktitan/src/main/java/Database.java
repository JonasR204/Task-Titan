import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Handles creation of JDBC connections
 * to the MySQL database.
 */
public class Database {

    private static final String URL =
            "jdbc:mysql://localhost:3306/tasktitan_app";

    private static final String USER =
            "root";

    private static final String PASSWORD =
            "";

    /**
     * Creates a connection to the database.
     *
     * @return active JDBC connection
     * @throws SQLException if connection fails
     */
    public static Connection getConnection()
            throws SQLException {

        return DriverManager.getConnection(
                URL,
                USER,
                PASSWORD
        );
    }
}