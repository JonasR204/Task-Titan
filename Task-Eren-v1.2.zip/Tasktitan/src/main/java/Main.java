import java.sql.Connection;

public class Main {

    public static void main(String[] args) {

        try (Connection con = Database.getConnection()) {

            System.out.println("CONNECTED SUCCESSFULLY");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}