package com.tasktitan.gui.controllers;

//moe and younes

public class AppContext {

    private static DashboardController dashboardController;

    public static void setDashboardController(DashboardController controller) {
        dashboardController = controller;
    }

    public static DashboardController getDashboardController() {
        return dashboardController;
    }
}