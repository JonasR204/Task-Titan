package com.tasktitan.gui;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;



public class HelloApplication extends Application {

    @Override
    public void start(Stage stage) throws Exception {

        FXMLLoader fxmlLoader = new FXMLLoader(
                HelloApplication.class.getResource(
                        "/com.tasktitan.gui/fxml/dashboard.fxml"
                )

        );


        Parent root = fxmlLoader.load();
        //set width and height by younes
       Scene scene = new Scene(root, 1280, 720);

        stage.setTitle("TaskTitan");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}