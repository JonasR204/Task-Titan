package com.tasktitan.gui.controllers;


import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import model.Task;
import model.BugTask;
import model.FeatureTask;
import model.TaskType;


public class TaskDetailsController {

    @FXML
    private VBox bugBox;

    @FXML
    private VBox featureBox;

    @FXML
    private TextArea descriptionArea;

    @FXML
    private TextArea codePartArea;

    @FXML
    private TextArea errorMessageArea;

    @FXML
    private TextArea fixPropositionArea;

    @FXML
    private TextArea technicalSpecificationArea;


    /**
     * Displays the details of the selected task in the task details window.
     * If the task is a bug, the bug-specific fields are shown.
     * If the task is a feature, the feature-specific fields are shown.
     */
    public void setTask(Task task) {

        descriptionArea.setText(task.getDescription());
        System.out.println("details button clicked");

        if (task.getTaskType() == TaskType.BUG) {

            BugTask bug = (BugTask) task;

            bugBox.setVisible(true);
            bugBox.setManaged(true);


            featureBox.setVisible(false);
            featureBox.setManaged(false);

            // old : codePartArea.setText(bug.getCodePart());
            codePartArea.setText(bug.GetCodePart());
            //old: errorMessageArea.setText(bug.getErrorMessage());
            errorMessageArea.setText(bug.GetErrorMessage());
            //old: fixPropositionArea.setText(bug.getFixProposition());
            fixPropositionArea.setText(bug.GetFixProposition());

        } else {

            FeatureTask feature = (FeatureTask) task;

            featureBox.setVisible(true);
            featureBox.setManaged(true);

            bugBox.setVisible(false);
            bugBox.setManaged(false);

            featureBox.setLayoutY(192);

            technicalSpecificationArea.setText(feature.getTechnicalSpecification());
        }
    }


}