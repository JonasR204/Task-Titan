package com.tasktitan.gui.controllers;



public class AppContext {

    private static DashboardController dashboardController;

    public static void setDashboardController(DashboardController controller) {
        dashboardController = controller;
    }

    public static DashboardController getDashboardController() {
        return dashboardController;
    }
}